public class cot
{
  tan ta;
  public cot()
  {
    ta = new tan(0);
  }
  public cot(double angle)
  {
    ta = new tan(angle);
  }
  public double cot()
  {
    //returns 1/tan
    return (1/(ta.tan()));
  }
}