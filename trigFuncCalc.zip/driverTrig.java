import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;
import javax.swing.*;
import java.io.*;
import java.util.*;
//mad imports
public class driverTrig
{
  public static void main(String [] args)
  {
    //Creates a JFrame
    JFrame frame = new JFrame("Trig Function Calculator");
    //Calls ButtonUser constructor
    ButtonUser b = new ButtonUser(frame); 
  }
}