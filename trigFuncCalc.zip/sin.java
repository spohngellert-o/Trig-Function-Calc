public class sin
{
  double angle;
  public sin()
  {
    angle = 0;
  }
  public sin(double a)
  {
    angle=a;
  }
  /*Olie spohngellert
   * gets the angle*/
  public double getAngle()
  {
    return angle;
  }
  /*sets the angle*/
  public void setAngle(double a)
  {
    angle = a;
  }
  /*Factorial calculator(same as in cos)*/
  public int factorial(int x)
  {
    if(x == 0)
    {
      return 1;
    }
    else
    {
      return x*factorial(x-1);
    }
  }
  public double sin(int times)
  {
    //base case
    if(times >=26)
    {
      return 0;
    }
    //if times is even it returns sin(times +1)
    if(times % 2 == 0)
    {
      return 0 + sin(times+1);
    }
    else
    {
      //if times mod 4 = 1
      if(times%4==1)
      {
        //returns angle^times/times! + sin(times+1
        return Math.pow(Math.toRadians(angle), times)/factorial(times) 
          + sin(times+1);
      }
      if(times %4 == 3)
      {
        //returns -1*angle^times/times! + sin(times+1
        return -1*Math.pow(Math.toRadians(angle), times)/factorial(times) + 
          sin(times+1);
      }
    }
    return sin(times+1);
  }
}