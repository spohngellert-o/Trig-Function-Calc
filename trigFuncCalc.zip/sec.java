public class sec
{
  cos co;
  public sec()
  {
    co = new cos(0);
  }
  public sec(double angle)
  {
    co = new cos(angle);
  }
  public double sec()
  {
    //returns 1/cos
    return (1/(co.cos(0)));
  }
}