public class cos
{
  double angle;
  public cos()
  {
    angle = 0;
  }
  public cos(double a)
  {
    angle=a;
  }
  /*Olie Spohngellert
   * getAngle()
   * returns the angle*/
  public double getAngle()
  {
    return angle;
  }
  /*Olie Spohngellert
   * setAngle(double a)
   * sets the angle*/
  public void setAngle(double a)
  {
    angle = a;
  }
  /*Olie Spohngellert
   * factorial(int x)
   * finds the factorial of x*/
  public int factorial(int x)
  {
    //Base case: if x is 0 it returns 1
    if(x == 0)
    {
      return 1;
    }
    //Else it returns x*factrial(x-1)
    else
    {
      return x*factorial(x-1);
    }
  }
  /*Olie Spohngellert
   * cos(int times)
   * returns cos of the angle
   * times: represents the number of iterations that have been passed*/
  public double cos(int times)
  {
    //if it has reached the base case it returns 0
    if(times >=26)
    {
      return 0;
    }
    //if times is odd it returns cos(times + 1)
    if(times % 2 == 1)
    {
      return 0 + cos(times+1);
    }
    //otherwise
    else
    {
      //if it is divisible by 4
      if(times%4==0)
      {
        //it returns angle(in radians)^times/times!+cos(times+1)
        return Math.pow(Math.toRadians(angle), times)/factorial(times) 
          + cos(times+1);
      }
      //if it is not divisible by 4
      if(times%4==2)
      {
        //returns -1*angle^times/times!+cos(times+1)
        return -1*Math.pow(Math.toRadians(angle), times)/factorial(times) + 
          cos(times+1);
      }
    }
    //just to avoid a compile error
    return cos(times+1);
  }
}