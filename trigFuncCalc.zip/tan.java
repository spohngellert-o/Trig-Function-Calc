public class tan
{
  cos Cos;
  sin Sin;
  public tan()
  {
    Cos = new cos(0);
    Sin = new sin(0);
  }
  public tan(double angle)
  {
    Cos = new cos(angle);
    Sin = new sin(angle);
  }
  public double tan()
  {
    //tan = sin/cos so it calculates that
    double yay = Sin.sin(0)/Cos.cos(0);
    return yay;
  }
}