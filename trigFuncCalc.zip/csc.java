public class csc
{
  sin si;
  public csc()
  {
    si = new sin(0);
  }
  public csc(double angle)
  {
    si = new sin(angle);
  }
  public double csc()
  {
    //returns 1/sin
    return (1/(si.sin(0)));
  }
}