import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;
import javax.swing.*;
import java.io.*;
import java.util.*;
public class ButtonUser
{
  //instance variables
  int confirm;
  private JFrame frame2;
  private JButton sin, cos, tan, sec, csc, cot;
  private JPanel pane;
  //constructor
  public ButtonUser(JFrame frame)
  { 
    //Creates the pane and all the buttons
    pane = new JPanel();
    sin = new JButton("sin");
    cos = new JButton("cos");
    tan = new JButton("tan");
    sec = new JButton("sec");
    csc = new JButton("csc");
    cot = new JButton("cot");
    //adds the buttons to the pane
    pane.add(sin);
    pane.add(cos);
    pane.add(tan);
    pane.add(sec);
    pane.add(csc);
    pane.add(cot);
    //adds actionlisteners to the buttons
    sin.addActionListener(new AListener());
    cos.addActionListener(new AListener());
    tan.addActionListener(new AListener());
    sec.addActionListener(new AListener());
    csc.addActionListener(new AListener());
    cot.addActionListener(new AListener());
    //Adds the pane to the frame
    frame.add(pane, BorderLayout.CENTER);
    //creates a frame local to the class so it can be used in AListener which
    //is set visible
    frame2 = frame;
    frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    frame2.setPreferredSize(new Dimension(400, 200));
    frame2.pack();
    frame2.setVisible(true);
  }
  private class AListener implements ActionListener
  {
    public void actionPerformed(ActionEvent e)
    {
      //Asks the user for the angle
        double angle = Double.parseDouble(JOptionPane.showInputDialog(null,
                                                                      "What's the "
                                                                        + "angle?"));
        //Checks which button is pressed
        if(e.getSource().equals(sin))
        {
          //Calculates sin if it is sin
          sin si = new sin(angle);
          double sin = si.sin(0);
          JOptionPane.showMessageDialog(null, "sin(" + angle + ") =" + sin); 
        }
        if(e.getSource().equals(cos))
        {
          //calculates cos
          cos co = new cos(angle);
          double cos = co.cos(0);
          JOptionPane.showMessageDialog(null, "cos(" + angle + ") =" + cos);
        }
        if(e.getSource().equals(tan))
        {
          //calculates tan
          tan ta = new tan(angle);
          double tan = ta.tan();
          JOptionPane.showMessageDialog(null, "tan(" + angle + ") =" + tan);
        }
        if(e.getSource().equals(sec))
        {
          //calculates sec
          sec se = new sec(angle);
          double sec = se.sec();
          JOptionPane.showMessageDialog(null, "sec(" + angle + ") =" + sec);
        }
        if(e.getSource().equals(csc))
        {
          //calculates csc
          csc cs = new csc(angle);
          double csc = cs.csc();
          JOptionPane.showMessageDialog(null, "csc(" + angle + ") =" + csc);
        }
        if(e.getSource().equals(cot))
        {
          //calculates cot
          cot co = new cot(angle);
          double cot = co.cot();
          JOptionPane.showMessageDialog(null, "cot(" + angle + ") =" + cot);
        }
    }
  }
}